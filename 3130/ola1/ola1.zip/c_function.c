/*Ross Bearden	
CSCI 3130
OLA 1
1/28/2016
*/

#include <stdio.h>

void printString(const char* message, const char* message1,
				const char* message2, const char* author){
	//Using puts function to print out the message
	puts(message);
	puts(message1);
	puts(message2);
	puts(author);
	return;
}